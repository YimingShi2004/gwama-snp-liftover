# Reproducing the reported run

## Original production and the portable release

The four files in `reproduction/original/` are byte-identical copies of the scripts supplied for the author's validated MCH/MCV/RDW run. Their hashes are in `reproduction/archive_sha256.json`. They retain their original project defaults and naming conventions. They record the exact implemented scientific procedure independently of the portable public interface.

The public `scripts/` versions add explicit trait-to-file mappings, profile-relative paths and configurable resources. The production scientific rules are retained. Their configuration version is `GWAMA_SNP_liftover_v1`, while the original production version is `Drug_rankGWAS_UCSC_SNP_v1`. A portable run should use a new output directory; it must not be pointed at the original directory to replace the original resume manifest. The public final auditor recognises both versions.

The existing accepted files do not need to be regenerated to prepare a repository release. Their completed-run manifests remain the authoritative provenance for those files. The summaries distributed here are author-reported records, not reconstructed full datasets or newly computed estimates.

## What was run

1. Inspect three compressed GWAMA files and identify the 19-column profile and composite marker representation.
2. Use an official direct hg19-to-hg38 chain and the existing indexed GRCh38 primary FASTA; test the first 10,000 rows per trait.
3. Run the production converter sequentially across traits with 500,000-row chunks, two pigz compression threads, and a SLURM request for four CPUs and 24 GiB RAM.
4. Complete source gzip scans to EOF; preserve passing SNPs and all other rows in separate files; assemble final gzip outputs from compressed chunk members.
5. Independently compare the final-file SHA256 values to production records and verify manifest fingerprints, chunk accounting and output schemas. The author reported `[SNP_LIFTOVER_FINAL_AUDIT_PASS]`.

The prefix pilot contained 30,000 passing SNPs on positive-strand mappings. Reverse-strand evidence came from production, not the prefix pilot. The completed production checked 96,338, 96,732 and 94,073 reverse-strand records for MCH, MCV and RDW, respectively.

## What the fingerprints do and do not record

`run_manifest.json` records source-file size/mtime/path fingerprints, the forward chain and executable SHA256 values, the `.fai` SHA256, FASTA size/mtime/path, chunk size, Python version and the script SHA256. It does **not** record a full SHA256 of the original multi-gigabyte GWAS inputs or FASTA. Output chunk and final-file hashes are computed explicitly.

The original absolute paths and full resource fingerprints were not supplied for this code release, so they are not invented or substituted with hashes from the developer's validation machine. `scripts/export_provenance.py` can export the actual completed run's metadata with absolute paths replaced by basenames. Keep the unredacted manifest with the run for resume and local final auditing.

## Testing coverage

Standard-library unit tests exercise input labels, profile path resolution, marker parsing, allele transformations, output accounting and integrity failures. A separate native regression uses the real UCSC executable with generated miniature FASTA/chain fixtures, including reverse and ambiguous maps. Human assembly-size checks are exercised independently; the miniature-genome integration test bypasses only the human-size preflight. The native test is opt-in because UCSC executables are not redistributed.

These tests validate implementation behaviour. They do not reproduce the approximately 150.7 million input records, estimate a new biological effect or establish downstream LD/GRN validity. The production QC table should be cited as the recorded application of the original scripts, with exact input/reference fingerprints retained by the author.
