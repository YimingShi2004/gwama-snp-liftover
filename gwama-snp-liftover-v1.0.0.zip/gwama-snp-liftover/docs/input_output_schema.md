# Input and output schema

## Accepted input profile

The workflow targets the audited 19-column quantitative-trait GWAMA profile. A marker such as `10:100000625_A_G` contains chromosome 10, a **1-based GRCh37** position and two allele labels. The field is not required to contain a dbSNP rsID. The allele-label order in the marker is not used to assign a genomic reference allele.

| Input column | Treatment |
|---|---|
| `rs_number` | Parsed for coordinate and allele-pair checks; original value retained as `rs_number_GRCh37` |
| `reference_allele` | Reported effect allele; original value retained as `reference_allele_GRCh37` |
| `other_allele` | Reported non-effect allele; original value retained as `other_allele_GRCh37` |
| `eaf` | Effect-allele frequency; original text retained |
| `beta`, `se`, `beta_95L`, `beta_95U`, `z` | Original text retained |
| `p-value`, `_-log10_p-value`, `chi-squared_GCcorr`, `p-value_GCcorr` | Original text retained; no new P-value or genomic-control transformation |
| `q_statistic`, `q_p-value`, `i2`, `n_studies`, `n_samples`, `effects` | Original text retained |

The parser accepts only the specified schema. Its production header gate checks 19 unique names and the required marker, allele and main statistical names. It does not infer arbitrary column aliases, alternative builds, indel representations or effect units. A 44-column or otherwise different format needs a separate explicit adapter.

## Output columns

Accepted output has the 19 original columns, with the three source marker/allele names renamed above, plus these 14 columns:

| Added field | Definition |
|---|---|
| `source_row` | One-based data-row index, excluding the input header |
| `chr37`, `pos37` | Parsed source chromosome and one-based position |
| `chr38`, `pos38` | Mapped target chromosome and one-based position; not a certified variant for review rows |
| `lift_strand` | Target mapping strand returned from a `+`-strand BED6 input |
| `reference_allele_hg38`, `other_allele_hg38` | Reported effect/non-effect alleles on the target forward strand |
| `REF_hg38` | Target FASTA base |
| `ALT_hg38` | The other allele after successful SNP validation |
| `variant_id_hg38` | `chr:pos:REF:ALT` identifier constructed for a passing SNP |
| `ALT_hg38_from` | `reference_allele_GRCh37` or `other_allele_GRCh37`, identifying genomic ALT's original allele role |
| `liftover_qc` | Mutually exclusive status below |
| `mapping_candidates` | Distinct mapped tuples; start is displayed one-based and end is the BED exclusive end, numerically equal to a one-based inclusive end |

Review output adds `raw_line_base64` as column 34. It contains the original row payload when the column count is malformed; other rows use `NA`. Malformed original fields are represented by `NA`, allowing a fixed review schema without losing the raw row bytes. Missing output attributes use `NA`.

## Mutually exclusive production statuses

| Status | Interpretation |
|---|---|
| `PASS` | Eligible biallelic SNP; one distinct canonical, one-base destination; transformed allele pair matches target FASTA |
| `BAD_COLUMN_COUNT` | Data-row field count differs from the input header |
| `BAD_ID` | Marker cannot be parsed by the supported composite-ID pattern |
| `BAD_SOURCE_COORD` | Parsed chromosome is outside the supported canonical set, or source position is out of chain bounds |
| `NON_SNP_NEEDS_VARIANT_LIFTOVER` | A label is not a single A/C/G/T base, or the marker labels are identical; includes non-SNP and unsupported/invalid allele representations |
| `ID_ALLELE_MISMATCH` | Marker allele set differs from the reported allele pair |
| `NO_MAP` | An eligible SNP has no returned destination |
| `MULTI_MAP` | More than one distinct chromosome/start/end/strand tuple is returned by the supplied chain |
| `NON_PRIMARY_OR_NON_1BP` | A unique mapped interval is noncanonical or does not span one base |
| `FASTA_N` | Target base is N |
| `ALLELE_MISMATCH` | Target A/C/G/T base matches neither transformed allele |

The pilot uses the shorter label `NON_SNP_OR_INVALID_ALLELE` for its corresponding pre-mapping exclusion, and stops on a malformed input row. Production preserves malformed rows in review. `NO_MAP` is initially used internally for eligible SNPs and becomes the final status only if no destination is returned.

The genomic REF/ALT and position fields appearing in review records are diagnostic candidates, not passing variants. Only records in `.SNP.GRCh38.tsv.gz` are the accepted dataset.

## Counters and denominators

```text
INPUT = PASS + REVIEW
INPUT = ELIGIBLE_SNP + pre-mapping exclusions
ELIGIBLE_SNP = PASS + NO_MAP + MULTI_MAP + NON_PRIMARY_OR_NON_1BP + FASTA_N + ALLELE_MISMATCH
FASTA_CHECKED = PASS + FASTA_N + ALLELE_MISMATCH
FASTA_CHECKED = PLUS_CHECKED + MINUS_CHECKED
PASS = PLUS_PASS + MINUS_PASS
```

Pre-mapping exclusions are `BAD_COLUMN_COUNT`, `BAD_ID`, `BAD_SOURCE_COORD`, `NON_SNP_NEEDS_VARIANT_LIFTOVER` and `ID_ALLELE_MISMATCH`. Every input row has exactly one final status. Additional counters such as `FASTA_CHECKED` are observations, not extra excluded records; summing every numeric QC column would double-count records.

| Metric | Denominator |
|---|---|
| SNP retention | `PASS / ELIGIBLE_SNP` |
| `PAIR_MATCH_RATE` | `PASS / FASTA_CHECKED` |
| `PLUS_MATCH_RATE` | `PLUS_PASS / PLUS_CHECKED` |
| `MINUS_MATCH_RATE` | `MINUS_PASS / MINUS_CHECKED` |

Rates with zero denominators are `NA`. A high FASTA pair-match rate alone is not a statement that all input records were converted.

## Remaining downstream work

Mapping uniqueness is defined within the supplied chain for each row. Two different source rows can still yield the same target identifier; no genome-wide target deduplication is performed. No global target sorting, rsID reassignment, alternative-contig rescue, mitochondrial conversion, indel reanchoring, effect-unit conversion, LD harmonisation or P-value selection is performed in this stage.
